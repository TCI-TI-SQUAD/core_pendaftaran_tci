require('./bootstrap');
const Swal = window.Swal = require('sweetalert2');