

<?php $__env->startSection('title',$data['title']); ?>
<?php $__env->startSection('subject',$data['subject']); ?>

<?php $__env->startSection('content'); ?>
    <?php echo $data['message']; ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.email.email_layout.email-layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Pendaftaran_tci\core\resources\views/admin/email/email_user/email-user.blade.php ENDPATH**/ ?>