

<?php $__env->startSection('siswa','active'); ?>

<?php $__env->startSection('page-name-header','Siswa'); ?>

<?php $__env->startSection('breadcrumb-item'); ?>
<li class="breadcrumb-item"><a href="<?php echo e(route('admin.dashboard')); ?>">Admin</a></li>
<li class="breadcrumb-item active">Siswa</li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-12 mb-4">
        <a href="<?php echo e(route('admin.trashed.siswa.index')); ?>" class="btn btn-sm btn-info"><i class="far fa-trash-alt"></i> LIHAT TRASHED SISWA</a>
        <a href="<?php echo e(route('admin.create.siswa')); ?>" class="btn btn-sm btn-success"><i class="far fa-edit"></i> BUAT SISWA BARU</a>
    </div>
    <div class="col-12 jumbotron p-2 shadow">
        <table class="table responsive nowrap" width="100%" id="table_id">
        <thead>
            <tr>
            <th scope="col">#</th>
            <th scope="col">Nama</th>
            <th scope="col">Username</th>
            <th scope="col">HSK</th>
            <th scope="col">Nomor Pelajar TCI</th>
            <th scope="col">Status</th>
            <th scope="col">email</th>
            <th scope="col">Phone Number</th>
            <th scope="col">Line</th>
            <th scope="col">Wa</th>
            <th scope="col">Alamat</th>
            <th scope="col">Hak Akses</th>
            <th scope="col">Created At</th>
            <th scope="col">Updated At</th>
            <th scope="col">Aksi</th>
            </tr>
        </thead>
        <tbody>
        </tbody>
        </table>
    </div>

</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('css'); ?>
    <!-- DataTables -->
    <link rel="stylesheet" href="<?php echo e(asset('plugins\datatables-bs4\css\dataTables.bootstrap4.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('plugins\datatables-responsive\css\responsive.bootstrap4.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('plugins\datatables-buttons\css\buttons.bootstrap4.min.css')); ?>">
<?php $__env->stopPush(); ?>

<?php $__env->startPush('js'); ?>
<script src="<?php echo e(asset('plugins/datatables/jquery.dataTables.min.js')); ?>"></script>
<script src="<?php echo e(asset('plugins/datatables-bs4/js/dataTables.bootstrap4.min.js')); ?>"></script>
<script src="<?php echo e(asset('plugins/datatables-responsive/js/dataTables.responsive.min.js')); ?>"></script>
<script src="<?php echo e(asset('plugins/datatables-responsive/js/responsive.bootstrap4.min.js')); ?>"></script>
<script src="<?php echo e(asset('plugins/datatables-buttons/js/dataTables.buttons.min.js')); ?>"></script>
<script src="<?php echo e(asset('plugins/datatables-buttons/js/buttons.bootstrap4.min.js')); ?>"></script>
<script src="<?php echo e(asset('plugins/jszip/jszip.min.js')); ?>"></script>
<script src="<?php echo e(asset('plugins/pdfmake/pdfmake.min.js')); ?>"></script>
<script src="<?php echo e(asset('plugins/pdfmake/vfs_fonts.js')); ?>"></script>
<script src="<?php echo e(asset('plugins/datatables-buttons/js/buttons.html5.min.js')); ?>"></script>
<script src="<?php echo e(asset('plugins/datatables-buttons/js/buttons.print.min.js')); ?>"></script>
<script src="<?php echo e(asset('plugins/datatables-buttons/js/buttons.colVis.min.js')); ?>"></script>

<script>
    $(document).ready( function () {

        $('#table_id').DataTable({
            responsive: true,
            dom: 'Bfrtip',
            buttons: [
                'pageLength',
                {
                extend: 'copyHtml5',
                exportOptions: {
                    columns: ':visible',
                    search : 'applied',
                    modifer: {
                        page: 'all',
                    }
                }
            },
            {
                extend: 'excelHtml5',
                exportOptions: {
                    columns: ':visible',
                    search : 'applied',
                    modifer: {
                        page: 'all',
                    }
                },
                action: function(e, dt, button, config) {
                                     responsiveToggle(dt);
                                     $.fn.DataTable.ext.buttons.excelHtml5.action.call(this, e, dt, button, config);
                                     responsiveToggle(dt);
                                 }
            },
            {
                extend: 'pdfHtml5',
                orientation: 'landscape',
                pageSize: 'LEGAL',
                exportOptions: {
                    columns: ':visible',
                    search : 'applied',
                    modifer: {
                        page: 'all',
                    }
                },
            },
            {
                extend: 'print',
                exportOptions: {
                    columns: ':visible',
                    search : 'applied',
                    modifer: {
                        page: 'all',
                    }
                },
            },
            {
                extend: 'colvis',
                columns: ':gt(0)'
            }
            ],
            "ajax": {
                "url": "<?php echo e(Route('admin.ajax.siswa')); ?>",
                "type": "POST",
                "data":{
                    "_token": "<?php echo e(csrf_token()); ?>"
                }
            },
            "columns": [
                { "data": "number" },
                { "data": "name" },
                { "data": "username" , "visible" : false},
                { "data": "hsk" },
                { "data": "nomor_pelajar_tci"},
                { "data": "status", "visible" : false},
                { "data": "email" },
                { "data": "phone_number" , "visible" : false},
                { "data": "line" , "visible" : false},
                { "data": "wa", "visible" : false },
                { "data": "alamat", "visible" : false },
                { "data": "hak_akses", "visible" : false },
                { "data": "created_at", "visible" : false },
                { "data": "updated_at", "visible" : false },
                {
                    data: "id",title:"Aksi",
                    render: function ( data, type, row ) {
                        return '<a href="<?php echo e(route("admin.detail.siswa")); ?>/'+data+'" class="btn btn-sm btn-primary"><i class="far fa-eye"></i></a><a href="<?php echo e(route("admin.edit.siswa")); ?>/'+data+'" class="btn text-white btn-sm btn-info"><i class="far fa-edit"></i></a><a class="btn text-white btn-sm btn-danger" onclick="deleteSiswa('+data+')"><i class="far fa-trash-alt"></i></a> <form id="delete-siswa-'+data+'" action="<?php echo e(route("admin.delete.siswa")); ?>" method="POST" style=" display: none;"> <?php echo csrf_field(); ?> <?php echo method_field("DELETE"); ?> <input name="id" value="'+data+'" type="hidden"></form>';
                    }
                }
            ]
        });
    } );

    function deleteSiswa(index){
            Swal.fire({
            title: 'Hapus siswa ini ?',
            html: 
            '<p>Berikut merupakan effect apabila admin menghapus user</p>'+
            '<ul class="text-left">'+
            '<li>User tidak akan bisa login</li>'+
            '<li>User tidak akan terlihat di semua kelas yang telah diikuti</li>'+
            '<li>Jumlah anggota kelas akan berkurang</li>'+
            '<li>User masih dapat dipulihkan dengan halaman <span class="text-info">TRASHED</span></li>'+
            '<li>User akan hilang dari semua report</li>'+
            '<li>Saat dipulihkan user akan kembali seperti semula</li>'+
            '</ul>'
            ,
            icon:'warning',
            showDenyButton: true,
            showCancelButton: false,
            confirmButtonText: `Hapus`,
            denyButtonText: `Batal`,
            }).then((result) => {
                
            if (result.isConfirmed) {
                $('#delete-siswa-'+index).submit();
            } else if (result.isDenied) {

            }
            })
        }
    
    // SWEETALERT2
        <?php if(Session::has('status')): ?>
            Swal.fire({
                icon:  <?php if(Session::has('icon')): ?><?php echo '"'.Session::get('icon').'"'; ?> <?php else: ?> 'question' <?php endif; ?>,
                title: <?php if(Session::has('title')): ?><?php echo '"'.Session::get('title').'"'; ?> <?php else: ?> 'Oppss...'<?php endif; ?>,
                text: <?php if(Session::has('message')): ?><?php echo '"'.Session::get('message').'"'; ?> <?php else: ?> 'Oppss...'<?php endif; ?>,
            });
        <?php endif; ?>
    // END
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('admin.admin-layout.admin-layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Pendaftaran_tci\core\resources\views/admin/admin/siswa/admin-siswa.blade.php ENDPATH**/ ?>