<div class="col-lg-3 col-6">
    <!-- small box -->
    <div class="small-box bg-info">
        <div class="inner">
        <h3><?php echo e($pendaftaran); ?></h3>

        <p style="white-space: nowrap;overflow: hidden;text-overflow: ellipsis;">Jumlah Pendaftaran Active</p>
        </div>
        <div class="icon">
        <i class="far fa-registered"></i>
        </div>
        <a href="#" class="small-box-footer">More info <i class="fas fa-arrow-circle-right"></i></a>
    </div>
</div><?php /**PATH C:\xampp\htdocs\Pendaftaran_tci\core\resources\views/livewire/admin/dashboard/pendaftaran-component.blade.php ENDPATH**/ ?>