<?php $__env->startPush('css'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('plugins\swiper\swiper-bundle.min.css')); ?>">
    <link href="<?php echo e(asset('asset\vendor\flipdown-master\dist\flipdown.min.css')); ?>" rel="stylesheet">
<?php $__env->stopPush(); ?>

<div class="col-12 col-xl-8">
    <div class="swiper-container mySwiper pb-4 h-100">
        <div class="swiper-wrapper">
            <?php if(isset($pendaftarans)): ?>
                <?php if(count($pendaftarans) > 0): ?>
                    <?php $__currentLoopData = $pendaftarans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $pendaftaran): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="swiper-slide d-flex justify-content-center align-items-center">
                                <div class="m-3">
                                    <h5 class="text-center m-3"><b><?php echo e($pendaftaran['nama_pendaftaran']); ?></b></h5>
                                    <div id="flipdown<?php echo e($index); ?>" class="flipdown"></div>
                                </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php else: ?>
                    <div class="swiper-slide d-flex justify-content-center align-items-center">
                            <div class="m-3">
                                <h5 class="text-center m-3"><b>Belum Ada Pendaftaran</b></h5>
                            </div>
                    </div>
                <?php endif; ?>
            <?php else: ?>
                <div class="swiper-slide d-flex justify-content-center align-items-center">
                        <div class="m-3">
                            <h5 class="text-center m-3"><b>Belum Ada Pendaftaran</b></h5>
                        </div>
                </div>
            <?php endif; ?>
        </div>
    </div>
</div>

<?php $__env->startPush('js'); ?>
    <script src="<?php echo e(asset('plugins\swiper\swiper-bundle.min.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(asset('asset\vendor\flipdown-master\dist\flipdown.min.js')); ?>"></script>
    <script>
        <?php if(isset($pendaftarans)): ?>
            <?php if(count($pendaftarans) > 0): ?>
                <?php $__currentLoopData = $pendaftarans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $pendaftaran): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                let flipdown<?php echo e($index); ?> = new FlipDown(<?php echo e(date_timestamp_get(date_create($pendaftaran['tanggal_selesai_pendaftaran']))); ?>,'flipdown<?php echo e($index); ?>');
                    flipdown<?php echo e($index); ?>.start();

                    var swiper = new Swiper(".mySwiper", {
                        spaceBetween: 30,
                        centeredSlides: true,
                        autoplay: {
                        delay: 3000,
                        disableOnInteraction: false,
                        },
                        pagination: {
                        el: ".swiper-pagination",
                        clickable: true,
                        },
                    });
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
        <?php endif; ?>
    </script>
<?php $__env->stopPush(); ?><?php /**PATH C:\xampp\htdocs\Pendaftaran_tci\core\resources\views/livewire/admin/dashboard/countdown-pengumuman-component.blade.php ENDPATH**/ ?>