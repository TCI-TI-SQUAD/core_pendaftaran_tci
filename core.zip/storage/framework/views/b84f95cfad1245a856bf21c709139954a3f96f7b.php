

<?php $__env->startSection('siswa','active'); ?>

<?php $__env->startSection('page-name-header','E-Mail Siswa'); ?>

<?php $__env->startSection('breadcrumb-item'); ?>
<li class="breadcrumb-item"><a href="<?php echo e(route('admin.dashboard')); ?>">Admin</a></li>
<li class="breadcrumb-item active"><a href="<?php echo e(route('admin.siswa')); ?>">Siswa</a></li>
<li class="breadcrumb-item active"><a href="<?php echo e(route('admin.detail.siswa',[$user->id])); ?>">Detail Siswa</a></li>
<li class="breadcrumb-item">E-Mail Siswa</li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-12 mb-4">
        <a href="<?php echo e(Route('admin.email.siswa.create',[$user->id])); ?>" class="btn btn-sm btn-success"><i class="far fa-edit"></i> BUAT E-MAIL BARU</a>
    </div>
    <div class="col-12 jumbotron p-2 shadow">
        <table class="table responsive nowrap" width="100%" id="table_id">
        <thead>
            <tr>
            <th scope="col">#</th>
            <th scope="col">Title</th>
            <th scope="col">Message</th>
            <th scope="col">Subject</th>
            <th scope="col">Aksi</th>
            </tr>
        </thead>
        <tbody>
        </tbody>
        </table>
    </div>

</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('css'); ?>
    <!-- DataTables -->
    <link rel="stylesheet" href="<?php echo e(asset('plugins\datatables-bs4\css\dataTables.bootstrap4.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('plugins\datatables-responsive\css\responsive.bootstrap4.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('plugins\datatables-buttons\css\buttons.bootstrap4.min.css')); ?>">
<?php $__env->stopPush(); ?>

<?php $__env->startPush('js'); ?>
<script src="<?php echo e(asset('plugins/datatables/jquery.dataTables.min.js')); ?>"></script>
<script src="<?php echo e(asset('plugins/datatables-bs4/js/dataTables.bootstrap4.min.js')); ?>"></script>
<script src="<?php echo e(asset('plugins/datatables-responsive/js/dataTables.responsive.min.js')); ?>"></script>
<script src="<?php echo e(asset('plugins/datatables-responsive/js/responsive.bootstrap4.min.js')); ?>"></script>
<script src="<?php echo e(asset('plugins/datatables-buttons/js/dataTables.buttons.min.js')); ?>"></script>
<script src="<?php echo e(asset('plugins/datatables-buttons/js/buttons.bootstrap4.min.js')); ?>"></script>
<script src="<?php echo e(asset('plugins/jszip/jszip.min.js')); ?>"></script>
<script src="<?php echo e(asset('plugins/pdfmake/pdfmake.min.js')); ?>"></script>
<script src="<?php echo e(asset('plugins/pdfmake/vfs_fonts.js')); ?>"></script>
<script src="<?php echo e(asset('plugins/datatables-buttons/js/buttons.html5.min.js')); ?>"></script>
<script src="<?php echo e(asset('plugins/datatables-buttons/js/buttons.print.min.js')); ?>"></script>
<script src="<?php echo e(asset('plugins/datatables-buttons/js/buttons.colVis.min.js')); ?>"></script>

<script>
    $(document).ready( function () {

        $('#table_id').DataTable({
            responsive: true,
            dom: 'Bfrtip',
            buttons: [
                'pageLength',
                {
                extend: 'copyHtml5',
                exportOptions: {
                    columns: ':visible',
                    search : 'applied',
                    modifer: {
                        page: 'all',
                    }
                }
            },
            {
                extend: 'excelHtml5',
                exportOptions: {
                    columns: ':visible',
                    search : 'applied',
                    modifer: {
                        page: 'all',
                    }
                },
                action: function(e, dt, button, config) {
                                     responsiveToggle(dt);
                                     $.fn.DataTable.ext.buttons.excelHtml5.action.call(this, e, dt, button, config);
                                     responsiveToggle(dt);
                                 }
            },
            {
                extend: 'pdfHtml5',
                orientation: 'landscape',
                pageSize: 'LEGAL',
                exportOptions: {
                    columns: ':visible',
                    search : 'applied',
                    modifer: {
                        page: 'all',
                    }
                },
            },
            {
                extend: 'print',
                exportOptions: {
                    columns: ':visible',
                    search : 'applied',
                    modifer: {
                        page: 'all',
                    }
                },
            },
            {
                extend: 'colvis',
                columns: ':gt(0)'
            }
            ],
            "ajax": {
                "url": "<?php echo e(Route('admin.ajax.email.siswa')); ?>",
                "type": "POST",
                "data":{
                    "_token": "<?php echo e(csrf_token()); ?>",
                    "id" : "<?php echo e($user->id); ?>"
                }
            },
            "columns": [
                { "data": "number" },
                { "data": "title" },
                { "data": "message" },
                { "data": "subject"},
                {
                    data: "id",title:"Aksi",
                    render: function ( data, type, row ) {
                        return '<a href="<?php echo e(route("admin.detail.siswa")); ?>/'+data+'" class="btn btn-sm btn-primary"><i class="far fa-eye"></i></a><a href="<?php echo e(route("admin.edit.siswa")); ?>/'+data+'" class="btn text-white btn-sm btn-info"><i class="far fa-edit"></i></a><a class="btn text-white btn-sm btn-danger" onclick="deleteEmailSiswa('+data+')"><i class="far fa-trash-alt"></i></a> <form id="delete-email-siswa-'+data+'" action="<?php echo e(route("admin.delete.siswa")); ?>" method="POST" style=" display: none;"> <?php echo csrf_field(); ?> <?php echo method_field("DELETE"); ?> <input name="id" value="'+data+'" type="hidden"></form>';
                    }
                }
            ],
            columnDefs: [{
                            render: function (data, type, full, meta) {
                                return "<div id='dvNotes' style='white-space: normal;width: 250px;'>" + data + "</div>";
                            },
                            targets: 2
                        }]
        });
    } );

    function deleteEmailSiswa(index){
            Swal.fire({
            title: 'Hapus siswa ini ?',
            html: 
            '<p>Berikut merupakan effect apabila admin menghapus e-mail user</p>'+
            '<ul class="text-left">'+
            '<li>E-mail yang sudah sampai ke E-mail user <span class="text-danger">TIDAK AKAN</span> ikut terhapus </li>'+
            '<li>catatan e-mail yang telah dihapus tidak akan dapat dipulihkan kembali</li>'+
            '</ul>'
            ,
            icon:'warning',
            showDenyButton: true,
            showCancelButton: false,
            confirmButtonText: `Hapus`,
            denyButtonText: `Batal`,
            }).then((result) => {
                
            if (result.isConfirmed) {
                $('#delete-siswa-'+index).submit();
            } else if (result.isDenied) {

            }
            })
        }
    
    // SWEETALERT2
        <?php if(Session::has('status')): ?>
            Swal.fire({
                icon:  <?php if(Session::has('icon')): ?><?php echo '"'.Session::get('icon').'"'; ?> <?php else: ?> 'question' <?php endif; ?>,
                title: <?php if(Session::has('title')): ?><?php echo '"'.Session::get('title').'"'; ?> <?php else: ?> 'Oppss...'<?php endif; ?>,
                text: <?php if(Session::has('message')): ?><?php echo '"'.Session::get('message').'"'; ?> <?php else: ?> 'Oppss...'<?php endif; ?>,
            });
        <?php endif; ?>
    // END
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('admin.admin-layout.admin-layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Pendaftaran_tci\core\resources\views/admin/admin/siswa/admin-email-siswa.blade.php ENDPATH**/ ?>