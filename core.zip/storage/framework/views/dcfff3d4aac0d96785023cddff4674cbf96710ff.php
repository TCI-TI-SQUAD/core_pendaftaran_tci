                    <li>        
                        <a class="text-dark <?php echo e(isset($home) ? 'font-weight-bold' : ''); ?>" href="<?php echo e(route('user.landing-page')); ?>">Home</a>
                    </li>
                    <li>
                        <a class="text-dark <?php echo e(isset($about) ? 'font-weight-bold' : ''); ?>" href="<?php echo e(route('user.about-page')); ?>">About</a>
                    </li>
                    <li  class="border-right pr-2">
                        <a class="text-dark <?php echo e(isset($contact) ? 'font-weight-bold' : ''); ?>" href="">Contact</a>
                    </li>
                    <li>
                        <a class="text-dark" href="<?php echo e(Route('user.login')); ?>">Log In</a>
                    </li>
                    <li>
                        <a href="<?php echo e(Route('user.register')); ?>">
                            <button type="button" class="btn btn-outline-success btn-register waves-effect">Register Here</button>
                        </a>
                    </li><?php /**PATH C:\xampp\htdocs\Pendaftaran_tci\core\resources\views/user-landing-page/user-landing-page-nav/user-landing-page-nav-wide.blade.php ENDPATH**/ ?>