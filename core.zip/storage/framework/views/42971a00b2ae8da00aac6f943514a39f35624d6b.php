<?php echo e($slot); ?>

<?php /**PATH C:\xampp\htdocs\Pendaftaran_tci\core\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/footer.blade.php ENDPATH**/ ?>