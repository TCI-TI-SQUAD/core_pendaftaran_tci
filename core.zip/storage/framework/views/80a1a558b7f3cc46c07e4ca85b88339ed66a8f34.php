<div class="col-lg-3 col-6">
    <!-- small box -->
    <div class="small-box bg-warning">
        <div class="inner">
        <h3><?php echo e($transaksi_menunggu_konfirmasi); ?></h3>

        <p style="white-space: nowrap;overflow: hidden;text-overflow: ellipsis;">Transaksi Menunggu Konfirmasi</p>
        </div>
        <div class="icon">
        <i class="fas fa-money-check-alt"></i>
        </div>
        <a href="#" class="small-box-footer">Lihat Transaksi <i class="fas fa-arrow-circle-right"></i></a>
    </div>
</div><?php /**PATH C:\xampp\htdocs\Pendaftaran_tci\core\resources\views/livewire/admin/dashboard/transaksi-menunggu-konfirmasi-component.blade.php ENDPATH**/ ?>