

<?php $__env->startPush('css'); ?>
<link href="<?php echo e(asset('asset\css\user\user-pembayaran.css')); ?>" rel="stylesheet">
<?php $__env->stopPush(); ?>

<?php $__env->startSection('navigation-wide'); ?>
    <?php echo $__env->make('user-dashboard.user-nav.top-nav-wide',['kelas_saya' => 'active'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('navigation-small'); ?>
    <?php echo $__env->make('user-dashboard.user-nav.top-nav-small',['kelas_saya' => 'active'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <?php if(isset($detail_kelas->id)): ?>
        <?php $encrypt_detail_kelas_id = Crypt::encryptString($detail_kelas->id)?>
    <?php endif; ?>
    <!-- CONTAINER -->
    <div class="container">
        <div class="row d-flex justify-content-center">
            
            <div class="col-12 mt-2">
                <nav aria-label="breadcrumb">
                    <ol class="breadcrumb bg-white">
                        <li class="breadcrumb-item"><a href="#" class="text-secondary font-weight-bold">Kelas Saya</a></li>
                        <li class="breadcrumb-item"><a href="#" class="text-secondary font-weight-bold">
                            <?php if(isset($detail_kelas->Kelas->nama_kelas)): ?><?php echo e($detail_kelas->Kelas->nama_kelas); ?><?php endif; ?>
                        </a></li>
                        <li class="breadcrumb-item active"><a href="" class="text-secondary font-weight-bold">Pembayaran</a></li>
                        <li class="breadcrumb-item active">Konfirmasi</li>
                    </ol>
                </nav>
            </div>

            <div class="col-12 m-0">
                <!-- Horizontal Steppers -->
                <div class="row m-0 justify-content-center align-items-center">
                    <div class="col-xl-2 col-lg-6 col-md-6 col-sm-6 col-xs-6 d-flex justify-content-center order-xl-1 order-lg-1">
                        <a href="<?php echo e(route('user.pembayaran.kelas',[$encrypt_detail_kelas_id])); ?>" class="btn btn-sm btn-outline-secondary">BACK</a>
                    </div>
                    <div class="col-xl-2 col-lg-6 col-md-6 col-sm-6 col-xs-6 d-flex justify-content-center order-xl-3 order-lg-2">
                        <a href="<?php echo e(route('user.upload.kelas',[$encrypt_detail_kelas_id])); ?>" class="btn btn-sm btn-secondary">NEXT</a>
                    </div>
                    <div class="col-xl-8 col-lg-12 col-md-12 col-sm-12 col-xs-12 order-xl-2  order-lg-3">

                        <!-- Stepers Wrapper -->
                        <ul class="stepper stepper-horizontal">
                            <!-- First Step -->
                            <li class="step">
                                <a href="#!">
                                <span class="circle bg-secondary f">1</span><small>KONFIRMASI</small>
                                </a>
                            </li>

                            <!-- Second Step -->
                            <li class="step">
                                <a href="#!">
                                <span class="circle">2</span><small>UPLOAD</small>
                                </a>
                            </li>
                            <!-- Third Step -->
                            <li class="step-actions">
                                <a href="#!">
                                <span class="circle">3</span><small>VERIFIKASI</small>
                                </a>
                            </li>

                            <!-- Third Step -->
                            <li class="step-actions">
                                <a href="#!">
                                <span class="circle">4</span><small>SELESAI</small>
                                </a>
                            </li>
                        </ul>
                        <!-- /.Stepers Wrapper -->

                    </div>
                </div>
                <!-- /.Horizontal Steppers -->
            </div>
        </div>

        <?php if(isset($detail_kelas->Transaksi)): ?>
                <div class="row d-flex justify-content-center p-2">
                    <div class="col-xl-8 col-md-8 col-12 jumbotron p-0 z-depth-1 d-flex flex-column justify-content-center align-items-center">
                        <div class="bg-secondary w-100" style="height:10px;"></div>
                        <div class="mt-3">
                            <h5 class="font-weight-bold text-secondary text-center">KONFIRMASI PEMESANAN DAN PEMBAYARAN</h5>
                        </div>
                        <div class="">
                            <p class="text-center">Bayar Sebelum <span class="text-secondary font-weight-bold">
                                <?php if(isset($detail_kelas->Transaksi->tanggal_expired)): ?>
                                    <?php echo e(Carbon\Carbon::create($detail_kelas->Transaksi->tanggal_expired)->translatedFormat('l , Y-M-d H:i:s').' WITA'); ?>

                                <?php endif; ?>
                            </span></p>
                        </div>
                        <div class="">
                            <h4 class="text-secondary font-weight-bold text-uppercase text-center"><?php if(isset($detail_kelas->Kelas->nama_kelas)): ?><?php echo e($detail_kelas->Kelas->nama_kelas); ?> <?php else: ?> Unknown Class <?php endif; ?></h4>
                        </div>
                        <div class="">
                            <h5 class="text-center"><span class="text-secondary font-weight-bold">IDR <?php if(isset($detail_kelas->Kelas->harga)): ?><?php echo e(number_format($detail_kelas->Kelas->harga)); ?> <?php else: ?> Unknown Class <?php endif; ?></span></h5>
                        </div>
                        <div class="">
                            <h5 class="text-center">Transfer pembayaran ke rekening atas nama</h5>
                        </div>
                        <div class="">
                            <h5 class="text-center">Admin Sistem TCI</h5>
                        </div>
                        <div class="d-flex justify-content-center align-items-center mb-3 mt-3">
                            <img src="<?php echo e(asset('storage\image_metode_pembayaran\bca.png')); ?>" alt="BANK BCA" style="display:block;marginL:auto;width:80px;">
                            123123213
                        </div>
                        
                        <div class="d-flex justify-content-center align-items-center mt-3">
                            <button class="btn btn-sm btn-outline-secondary" style="width:200px;">PANDUAN PEMBAYARAN</button>
                        </div>

                        <div class="d-flex justify-content-center align-items-center">
                            <a href="<?php echo e(route('user.upload.kelas',[$encrypt_detail_kelas_id])); ?>" class="btn btn-sm btn-secondary" style="width:200px;" form="form-upload-bukti">UPLOAD BUKTI</a>
                        </div>
                        
                        <?php if($detail_kelas->Transaksi->status != 'lunas'): ?>
                            <div class="d-flex justify-content-center align-items-center mb-3">
                                <a href="<?php echo e(route('user.upload.kelas',[$encrypt_detail_kelas_id])); ?>" class="btn btn-sm btn-danger" style="width:200px;" form="form-upload-bukti">BATALKAN PEMESANAN</a>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
        <?php endif; ?>

    </div>
    <!-- END COINTAINER -->
<?php $__env->stopSection(); ?>

<?php $__env->startPush('js'); ?>
<script>
        $(document).ready(function(){

            $('#navigation-button').click(function(){
                $('#navigation-block').toggleClass('active');
            })

            $('#navigation-button-close').click(function(){
                $('#navigation-block').toggleClass('active');
            })
        });
</script>
<script>
        // SWEETALERT2
        <?php if(Session::has('status')): ?>
                Swal.fire({
                    icon:  <?php if(Session::has('icon')): ?><?php echo '"'.Session::get('icon').'"'; ?> <?php else: ?> 'question' <?php endif; ?>,
                    title: <?php if(Session::has('title')): ?><?php echo '"'.Session::get('title').'"'; ?> <?php else: ?> 'Oppss...'<?php endif; ?>,
                    text: <?php if(Session::has('message')): ?><?php echo '"'.Session::get('message').'"'; ?> <?php else: ?> 'Oppss...'<?php endif; ?>,
                });
            <?php endif; ?>
        // END
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layout.main-layout.main-layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Pendaftaran_tci\core\resources\views/user-dashboard/user-kelas-saya/user-pembayaran.blade.php ENDPATH**/ ?>