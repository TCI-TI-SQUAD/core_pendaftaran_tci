            <div class="navigation-block-child mt-3">
                    <div class="text-center" style="margin:10px;width:50px;"><i class="fas fa-home"></i></div>
                    <div style="flex-grow:2;margin:10px;" class="<?php echo e(isset($home) ? 'font-weight-bold' : ''); ?>">Home</div>
            </div>
        
            <a href="<?php echo e(Route('user.about-page')); ?>" style="text-decoration:none;" class="text-dark">
            <div class="navigation-block-child mt-3">
                    <div class="text-center" style="margin:10px;width:50px;"><i class="fas fa-question"></i></div>
                    <div style="flex-grow:2;margin:10px;" class="<?php echo e(isset($about) ? 'font-weight-bold' : ''); ?>">About</div>
            </div>
            </a>
            
            <div class="navigation-block-child mt-3">
                    <div class="text-center" style="margin:10px;width:50px;"><i class="far fa-address-book"></i></div>
                    <div style="flex-grow:2;margin:10px;" class="<?php echo e(isset($contact) ? 'font-weight-bold' : ''); ?>">Contact</div>
            </div>

            <a href="<?php echo e(Route('user.login')); ?>" style="text-decoration:none;" class="text-dark">
                <div class="navigation-block-child mt-3">
                        <div class="text-center" style="margin:10px;width:50px;"><i class="fas fa-sign-in-alt"></i></div>
                        <div style="flex-grow:2;margin:10px;">Log In</div>
                </div>
            </a>

            <a href="<?php echo e(Route('user.register')); ?>" style="text-decoration:none;" class="text-dark">
                <div class="navigation-block-child mt-3">
                    <div class="text-center" style="margin:10px;width:50px;"><i class="far fa-registered"></i></div>
                    <div style="flex-grow:2;margin:10px;">Register</div>
                </div>
            </a><?php /**PATH C:\xampp\htdocs\Pendaftaran_tci\core\resources\views/user-landing-page/user-landing-page-nav/user-landing-page-nav-small.blade.php ENDPATH**/ ?>