

<?php $__env->startPush('css'); ?>
<link href="<?php echo e(asset('asset\css\user\user-kelas-beranda.css')); ?>" rel="stylesheet">
<?php $__env->stopPush(); ?>

<?php $__env->startSection('navigation-wide'); ?>
    <?php echo $__env->make('user-dashboard.user-nav.top-nav-wide',['kelas_saya' => 'active'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('navigation-small'); ?>
    <?php echo $__env->make('user-dashboard.user-nav.top-nav-small',['kelas_saya' => 'active'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <!-- CONTAINER -->
    <div class="container">
        HALO
    </div>
    <!-- END COINTAINER -->
<?php $__env->stopSection(); ?>

<?php $__env->startPush('js'); ?>
<script>
        $(document).ready(function(){

            $('#navigation-button').click(function(){
                $('#navigation-block').toggleClass('active');
            })

            $('#navigation-button-close').click(function(){
                $('#navigation-block').toggleClass('active');
            })

            $(function () {
                $('[data-toggle="tooltip"]').tooltip()
            })
        });
</script>
<script>
        // SWEETALERT2
        <?php if(Session::has('status')): ?>
                Swal.fire({
                    icon:  <?php if(Session::has('icon')): ?><?php echo '"'.Session::get('icon').'"'; ?> <?php else: ?> 'question' <?php endif; ?>,
                    title: <?php if(Session::has('title')): ?><?php echo '"'.Session::get('title').'"'; ?> <?php else: ?> 'Oppss...'<?php endif; ?>,
                    text: <?php if(Session::has('message')): ?><?php echo '"'.Session::get('message').'"'; ?> <?php else: ?> 'Oppss...'<?php endif; ?>,
                });
            <?php endif; ?>
        // END
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layout.main-layout.main-layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Pendaftaran_tci\core\resources\views/user-dashboard/user-kelas-saya/kelas-beranda.blade.php ENDPATH**/ ?>