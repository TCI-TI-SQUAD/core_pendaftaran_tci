

<?php $__env->startPush('css'); ?>
<link href="<?php echo e(asset('asset\css\user\user-profile.css')); ?>" rel="stylesheet">
<?php $__env->stopPush(); ?>

<?php $__env->startSection('navigation-wide'); ?>
    <?php echo $__env->make('user-dashboard.user-nav.top-nav-wide',['profile' => 'active'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('navigation-small'); ?>
    <?php echo $__env->make('user-dashboard.user-nav.top-nav-small',['profile' => 'active'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <!-- CONTAINER -->
    <div class="container-fluid">
        <div class="row z-depth-3" style="height:45vh; overflow:hidden;">
            <div class="col-12 p-0 m-0">
                <img src="<?php echo e(asset('asset\image\main_asset\profile-decoration.jpg')); ?>" id="image_background" alt="">
            </div>
        </div>
        <div class="container position-relative" style="top:-130px;">
            <div class="row">
                <div class="col-12 col-lg-8 m-auto p-0">
                    <div class="jumbotron border-secondary mt-3 animated slideInUp" style="border-top:10px solid;">
                        <div class="container">
                            <a href="<?php echo e(route('user.profile.edit')); ?>" class="btn btn-sm btn-outline-secondary rounded position-absolute d-lg-block d-none" style="font-size:20px;right:10px;top:10px;z-index:1;"><i class="fas fa-edit"></i> EDIT</a>
                            <div class="row position-relative">
                                <?php if(isset($user)): ?>
                                    <div class="col-12 text-center position-absolute animated slideInDown" id="image_profile">
                                        <a href="<?php echo e(asset('storage\image_users').'/'.$user->user_profile_pict); ?>" target="__blank">
                                            <img class="img-thumbnail z-depth-2 rounded-circle" src="<?php echo e(asset('storage\image_users').'/'.$user->user_profile_pict); ?>" alt="" style="object-fit:cover;width:170px;height:170px;">
                                        </a>
                                    </div>
                                    <div class="col-12 mt-5">
                                        <h5 class="text-center mt-3"><?php echo e($user->name); ?></h5>
                                        <p class="text-center m-0"><small >Alsan</small></p>
                                        <p class="text-center m-4">
                                            <?php if($user->hsk == 'pemula'): ?>
                                                <span class="blue-grey lighten-3 p-2 rounded font-weight-bold">PEMULA</span>
                                            <?php elseif($user->hsk == 'hsk 1'): ?>
                                                <span class="yellow lighten-1 p-2 rounded font-weight-bold">HSK 1</span>  
                                            <?php elseif($user->hsk == 'hsk 2'): ?>
                                                <span class="yellow darken-5 darken-2 p-2 rounded font-weight-bold">HSK 2</span>  
                                            <?php elseif($user->hsk == 'hsk 3'): ?>
                                                <span class="yellow darken-4 darken-2 p-2 rounded font-weight-bold">HSK 3</span>
                                            <?php elseif($user->hsk == 'hsk 4'): ?>
                                                <span class="aqua-gradient p-2 rounded font-weight-bold">HSK 4</span>  
                                            <?php elseif($user->hsk == 'hsk 5'): ?>
                                                <span class="blue-gradient p-2 rounded font-weight-bold">HSK 5</span>  
                                            <?php elseif($user->hsk == 'hsk 6'): ?>
                                                <span class="peach-gradient p-2 rounded font-weight-bold">HSK 6</span>  
                                            <?php else: ?>
                                                <span class="peach-gradient p-2 rounded font-weight-bold">PEMULA</span>  
                                            <?php endif; ?>
                                        </p>
                                        
                                        <label ><i class="fas fa-id-card-alt"></i> Nomor Pelajar TCI</label>
                                        <input type="text" class="form-control" value="<?php echo e($user->nomor_pelajar_tci); ?>" readonly>
                                        <label ><i class="fas fa-laptop-house"></i>Instansi</label>
                                        <input type="text" class="form-control" value="<?php echo e($user->getInstansiName()); ?>" readonly>
                                        <label class="mt-2"><i class="fas fa-envelope-square"></i> E-mail</label>
                                        <input type="text" class="form-control" value="<?php echo e($user->email); ?>" readonly>
                                        <label class="mt-2"><i class="fas fa-phone-square-alt"></i> Phone Number</label>
                                        <input type="text" class="form-control" value="<?php echo e($user->phone_number); ?>" readonly>
                                        <label class="mt-2"><i class="fab fa-line"></i> Line</label>
                                        <input type="text" class="form-control" value="<?php echo e($user->line); ?>" readonly>
                                        <label class="mt-2"> <i class="fab fa-whatsapp-square"></i> WA</label>
                                        <input type="text" class="form-control" value="<?php echo e($user->wa); ?>" readonly>
                                        <label class="mt-2"><i class="fab fa-line"></i> Kartu Identitas</label>
                                        <div class="text-center">
                                        <a href="<?php echo e(asset('storage/kartu_identitas').'/'.$user->kartu_identitas); ?>" target="__blank" class="btn btn-sm m-auto w-50 d-none d-lg-block btn-block btn-primary"><i class="far fa-eye"></i> LIHAT KARTU IDENTITAS</a>
                                        <a href="<?php echo e(asset('storage/kartu_identitas').'/'.$user->kartu_identitas); ?>" target="__blank" class="btn btn-sm m-auto w-100 d-block d-lg-none btn-block btn-primary"><i class="far fa-eye"></i> LIHAT KARTU IDENTITAS</a>
                                        <a href="<?php echo e(route('user.profile.edit')); ?>" class="btn btn-sm my-4 mx-auto d-block btn-outline-secondary rounded d-lg-none"><i class="fas fa-edit"></i> EDIT PROFILE</a>
                                        </div>
                                    </div>
                                <?php else: ?>
                                    <div class="col-12 text-center">
                                        TIDAK ADA PROFILE
                                    </div>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- END CONTAINER -->
<?php $__env->stopSection(); ?>

<?php $__env->startPush('js'); ?>
<script>
    $(document).ready(function(){

        $('#navigation-button').click(function(){
            $('#navigation-block').toggleClass('active');
        })

        $('#navigation-button-close').click(function(){
            $('#navigation-block').toggleClass('active');
        })
        
    });
</script>
<script>
        // SWEETALERT2
            <?php if(Session::has('status')): ?>
                Swal.fire({
                    icon:  <?php if(Session::has('icon')): ?><?php echo '"'.Session::get('icon').'"'; ?> <?php else: ?> 'question' <?php endif; ?>,
                    title: <?php if(Session::has('title')): ?><?php echo '"'.Session::get('title').'"'; ?> <?php else: ?> 'Oppss...'<?php endif; ?>,
                    text: <?php if(Session::has('message')): ?><?php echo '"'.Session::get('message').'"'; ?> <?php else: ?> 'Oppss...'<?php endif; ?>,
                });
            <?php endif; ?>
        // END
</script>

<?php $__env->stopPush(); ?>
<?php echo $__env->make('layout.main-layout.main-layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Pendaftaran_tci\core\resources\views/user-dashboard/user-profile/user-profile.blade.php ENDPATH**/ ?>