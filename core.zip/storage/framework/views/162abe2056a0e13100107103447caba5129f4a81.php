

<?php $__env->startPush('css'); ?>
<link href="<?php echo e(asset('asset\css\user\user-jadwal-kelas.css')); ?>" rel="stylesheet">
<?php $__env->stopPush(); ?>

<?php $__env->startSection('navigation-wide'); ?>
    <?php echo $__env->make('user-dashboard.user-nav.top-nav-wide',['pendaftaran' => 'active'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('navigation-small'); ?>
    <?php echo $__env->make('user-dashboard.user-nav.top-nav-small', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container">
        <div class="row">
            <div class="col">
                <nav aria-label="breadcrumb">
                    <ol class="breadcrumb bg-white m-3">
                        <li class="breadcrumb-item"><a href="<?php echo e(route('user.pendaftaran')); ?>" class="text-secondary font-weight-bold">Pendaftaran</a></li>
                        <li class="breadcrumb-item"><a href="<?php echo e(url()->current()); ?>" class="text-dark"><?php if(isset($kelas)): ?>Jadwal <?php echo e($kelas->nama_kelas); ?><?php endif; ?></a></li>
                    </ol>
                </nav>
            </div>
        </div>
    </div>

    <div class="container">
        <div class="row d-flex justify-content-center">

            <div class="col-md-12 col-sm-12 col-lg-4 m-1 p-0 animated slideInLeft">
                <!-- Card -->
                <div class="card" <?php if($kelas->isLocked): ?>style="opacity:0.6;"<?php endif; ?>>

                    <!-- Card image -->
                    <img class="card-img-top" src="<?php echo e(url('storage\image_kelas',[$kelas->logo_kelas])); ?>" alt="Card image cap" style="height:200px;object-fit:cover;">

                    <!-- Card content -->
                    <div class="card-body text-center">

                        <!-- Title -->
                        <h4 class="card-title" style="white-space: nowrap;overflow: hidden;text-overflow: ellipsis;"><a><?php echo e($kelas->nama_kelas); ?></a></h4>
                        <!-- Text -->
                        <div class="row mt-3">

                            <div class="col-12 d-flex justify-content-center align-items-start text-left">

                                <div>
                                    <?php $foto_pengajar = isset($kelas->Pengajar->foto_pengajar) ? $kelas->Pengajar->foto_pengajar : 'default.jpg' ?>
                                    <img src="<?php echo e(url('storage\image_pengajar',[$foto_pengajar])); ?>" alt="" class="rounded bg-secondary" style="width:80px;height:70px;object-fit:cover;display:block;margin:auto;">
                                </div>

                                <div class="ml-1">
                                    <small  style="white-space: nowrap;overflow: hidden;text-overflow: ellipsis;max-width:200px;" class="font-weight-bold">
                                        <?php if(isset($kelas->Pengajar->nama_pengajar)): ?>
                                            <?php echo e($kelas->Pengajar->nama_pengajar); ?>

                                        <?php else: ?>
                                            Pengajar belum ditentukan
                                        <?php endif; ?>
                                    </small>
                                    <div style="white-space: nowrap;overflow: hidden;text-overflow: ellipsis;"><small><?php echo e('Pengajar '.strtoupper($kelas->hsk)); ?></small></div>
                                    <div style="white-space: nowrap;overflow: hidden;text-overflow: ellipsis;" class="text-secondary"><small class="font-weight-bold"><?php echo e('Rp.'. number_format($kelas->harga)); ?></small></div>
                                </div>

                            </div>

                        </div>

                        <div class="row mt-4">
                            <div class="col">
                                <?php if($kelas->isLocked): ?>
                                    <small class="badge badge-pill badge-danger" data-toggle="tooltip" title="Kelas ini ditutup oleh admin">CLOSED</small>
                                <?php else: ?>
                                    <small class="badge badge-pill badge-success" data-toggle="tooltip" title="Kelas ini tersedia">OPEN</small>
                                <?php endif; ?>

                                <?php if($kelas->isBerbayar): ?>
                                    <small class="badge badge-pill badge-success" data-toggle="tooltip" title="Kelas ini berbayar">BERBAYAR</small>
                                <?php else: ?>
                                    <small class="badge badge-pill badge-warning" data-toggle="tooltip" title="Kelas ini Gratis">GRATIS</small>
                                <?php endif; ?>
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-sm-12 mt-3 text-center">
                                KUOTA
                            </div>
                            <div class="col-sm-12 text-center">
                                <?php echo e($kelas->DetailKelas->count().'/'.$kelas->kuota); ?>

                            </div>
                        </div>

                        <div class="row">
                            <div class="col-12 p-2 m-0">
                                <div class="progress border border-secondary">
                                    <div class="progress-bar bg-secondary" role="progressbar" style="width:<?php if($kelas->kuota != 0): ?><?php echo e(($kelas->DetailKelas->count()/$kelas->kuota*100).'%'); ?>;<?php endif; ?>"
                                    >
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-sm-12 col-md-12 col-lg-6 p-2">
                                <a href="<?php echo e(route('user.pendaftaran')); ?>" class="btn btn-block btn-outline-danger waves-effect <?php if($kelas->isLocked): ?> disabled <?php endif; ?>">Back</a>
                            </div>
                            <form action="<?php echo e(route('user.daftar.kelas')); ?>" method="POST" id="form-daftar-kelas-1" style="display:none;">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('POST'); ?>
                                <input name="id_kelas" type="text" value="<?php echo e(Crypt::encryptString($kelas->id)); ?>">
                            </form>
                            <div class="col-sm-12 col-md-12 col-lg-6 p-2">
                                <button onclick="daftarKelas(1,'<?php echo e($kelas->nama_kelas); ?>')" class="btn btn-success btn-block text-nowrap  <?php if($kelas->isLocked): ?> disabled <?php endif; ?>">Ikuti</button>
                            </div>
                        </div>
                        <!-- Button -->

                    </div>

                </div>
            </div>

            <div class="col-md-12 col-sm-12 col-lg-7 m-1 p-3 jumbotron animated slideInRight">
                <table class="mt-3">
                    <tr>
                        <th class="pr-2 font-weight-bold">
                            Tanggal Mulai
                        </th>
                        <td>
                            : <?php echo e(Carbon\Carbon::create($kelas->tanggal_mulai)->translatedFormat('l, Y-m-d')); ?>

                        </td>
                    </tr>
                    <tr>
                        <th class="pr-2 font-weight-bold">
                            Tanggal Selesai
                        </th>
                        <td>
                            : <?php echo e(Carbon\Carbon::create($kelas->tanggal_selesai)->translatedFormat('l, Y-m-d')); ?>

                        </td>
                    </tr>
                </table>
                <div class="table-responsive-sm">
                    <table class="table table-striped mt-3 text-nowrap">
                        <thead class="bg-primary text-white">
                            <tr>
                                <th scope="col">Nomor</th>
                                <th scope="col">Tanggal</th>
                                <th scope="col">Waktu Mulai</th>
                                <th scope="col">Waktu Selesai</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $real_period; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $period_jadwal): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($index+1); ?></td>
                                    <td><?php echo e($period_jadwal['period']->translatedFormat('l, Y-m-d')); ?></td>
                                    <td><?php echo e($period_jadwal['jadwal']->waktu_mulai.' '.strtoupper($period_jadwal['jadwal']->zona_waktu)); ?></td>
                                    <td><?php echo e($period_jadwal['jadwal']->waktu_selesai.' '.strtoupper($period_jadwal['jadwal']->zona_waktu)); ?></td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>

        </div>
        
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('js'); ?>
<script>
        $(document).ready(function(){

            $('#navigation-button').click(function(){
                $('#navigation-block').toggleClass('active');
            })

            $('#navigation-button-close').click(function(){
                $('#navigation-block').toggleClass('active');
            })
        });
        function daftarKelas(id_kelas,nama_kelas){
            Swal.fire({
            title: 'Yakin mengikuti kelas '+nama_kelas+' ?',
            icon:'question',
            showDenyButton: true,
            showCancelButton: false,
            confirmButtonText: `Ikuti`,
            denyButtonText: `Batal`,
            footer:'Saya telah menyetujui semua  &nbsp; <a href="#"> persyaratan dan persetujuan</a>',
            }).then((result) => {
                
            if (result.isConfirmed) {
                $('#form-daftar-kelas-'+id_kelas).submit();
            } else if (result.isDenied) {
            }
            })

        }
    </script>
<script>
    // SWEETALERT2
        <?php if(Session::has('status')): ?>
            Swal.fire({
                icon:  <?php if(Session::has('icon')): ?><?php echo '"'.Session::get('icon').'"'; ?> <?php else: ?> 'question' <?php endif; ?>,
                title: <?php if(Session::has('title')): ?><?php echo '"'.Session::get('title').'"'; ?> <?php else: ?> 'Oppss...'<?php endif; ?>,
                text: <?php if(Session::has('message')): ?><?php echo '"'.Session::get('message').'"'; ?> <?php else: ?> 'Oppss...'<?php endif; ?>,
            });
        <?php endif; ?>
    // END
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layout.main-layout.main-layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Pendaftaran_tci\core\resources\views/user-dashboard/user-jadwal-kelas.blade.php ENDPATH**/ ?>