

<?php $__env->startSection('siswa','active'); ?>

<?php $__env->startSection('page-name-header','Trashed Siswa'); ?>

<?php $__env->startSection('breadcrumb-item'); ?>
<li class="breadcrumb-item"><a href="<?php echo e(route('admin.dashboard')); ?>">Admin</a></li>
<li class="breadcrumb-item active"><a href="<?php echo e(route('admin.siswa')); ?>">Siswa</a></li>
<li class="breadcrumb-item">Trashed Siswa</li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-12 jumbotron p-2 shadow">
        <table class="table responsive nowrap" width="100%" id="table_id">
        <thead>
            <tr>
            <th scope="col">#</th>
            <th scope="col">Nama</th>
            <th scope="col">Username</th>
            <th scope="col">HSK</th>
            <th scope="col">Nomor Pelajar TCI</th>
            <th scope="col">Status</th>
            <th scope="col">email</th>
            <th scope="col">Phone Number</th>
            <th scope="col">Line</th>
            <th scope="col">Wa</th>
            <th scope="col">Alamat</th>
            <th scope="col">Hak Akses</th>
            <th scope="col">Created At</th>
            <th scope="col">Updated At</th>
            <th scope="col">Aksi</th>
            </tr>
        </thead>
        <tbody>
        </tbody>
        </table>
    </div>

</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('css'); ?>
    <!-- DataTables -->
    <link rel="stylesheet" href="<?php echo e(asset('plugins\datatables-bs4\css\dataTables.bootstrap4.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('plugins\datatables-responsive\css\responsive.bootstrap4.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('plugins\datatables-buttons\css\buttons.bootstrap4.min.css')); ?>">
<?php $__env->stopPush(); ?>

<?php $__env->startPush('js'); ?>
<script src="<?php echo e(asset('plugins/datatables/jquery.dataTables.min.js')); ?>"></script>
<script src="<?php echo e(asset('plugins/datatables-bs4/js/dataTables.bootstrap4.min.js')); ?>"></script>
<script src="<?php echo e(asset('plugins/datatables-responsive/js/dataTables.responsive.min.js')); ?>"></script>
<script src="<?php echo e(asset('plugins/datatables-responsive/js/responsive.bootstrap4.min.js')); ?>"></script>
<script src="<?php echo e(asset('plugins/datatables-buttons/js/dataTables.buttons.min.js')); ?>"></script>
<script src="<?php echo e(asset('plugins/datatables-buttons/js/buttons.bootstrap4.min.js')); ?>"></script>
<script src="<?php echo e(asset('plugins/jszip/jszip.min.js')); ?>"></script>
<script src="<?php echo e(asset('plugins/pdfmake/pdfmake.min.js')); ?>"></script>
<script src="<?php echo e(asset('plugins/pdfmake/vfs_fonts.js')); ?>"></script>
<script src="<?php echo e(asset('plugins/datatables-buttons/js/buttons.html5.min.js')); ?>"></script>
<script src="<?php echo e(asset('plugins/datatables-buttons/js/buttons.print.min.js')); ?>"></script>
<script src="<?php echo e(asset('plugins/datatables-buttons/js/buttons.colVis.min.js')); ?>"></script>

<script>
    $(document).ready( function () {

        $('#table_id').DataTable({
            responsive: true,
            dom: 'Bfrtip',
            buttons: [
                'pageLength',
                {
                extend: 'copyHtml5',
                exportOptions: {
                    columns: ':visible',
                    search : 'applied',
                    modifer: {
                        page: 'all',
                    }
                }
            },
            {
                extend: 'excelHtml5',
                exportOptions: {
                    columns: ':visible',
                    search : 'applied',
                    modifer: {
                        page: 'all',
                    }
                },
                action: function(e, dt, button, config) {
                                     responsiveToggle(dt);
                                     $.fn.DataTable.ext.buttons.excelHtml5.action.call(this, e, dt, button, config);
                                     responsiveToggle(dt);
                                 }
            },
            {
                extend: 'pdfHtml5',
                orientation: 'landscape',
                pageSize: 'LEGAL',
                exportOptions: {
                    columns: ':visible',
                    search : 'applied',
                    modifer: {
                        page: 'all',
                    }
                },
            },
            {
                extend: 'print',
                exportOptions: {
                    columns: ':visible',
                    search : 'applied',
                    modifer: {
                        page: 'all',
                    }
                },
            },
            {
                extend: 'colvis',
                columns: ':gt(0)'
            }
            ],
            "ajax": {
                "url": "<?php echo e(Route('admin.ajax.trashed.siswa')); ?>",
                "type": "POST",
                "data":{
                    "_token": "<?php echo e(csrf_token()); ?>"
                }
            },
            "columns": [
                { "data": "number" },
                { "data": "name" },
                { "data": "username" , "visible" : false},
                { "data": "hsk" },
                { "data": "nomor_pelajar_tci"},
                { "data": "status", "visible" : false},
                { "data": "email" },
                { "data": "phone_number" , "visible" : false},
                { "data": "line" , "visible" : false},
                { "data": "wa", "visible" : false },
                { "data": "alamat", "visible" : false },
                { "data": "hak_akses", "visible" : false },
                { "data": "created_at", "visible" : false },
                { "data": "updated_at", "visible" : false },
                {
                    data: "id",title:"Aksi",
                    render: function ( data, type, row ) {
                        return '<a class="btn text-white btn-sm btn-info" onclick="deleteSiswa('+data+')"><i class="fas fa-trash-restore"></i></a> <form id="delete-siswa-'+data+'" action="<?php echo e(route("admin.trashed.siswa.restore")); ?>" method="POST" style=" display: none;"> <?php echo csrf_field(); ?> <?php echo method_field("PUT"); ?> <input name="id" value="'+data+'" type="hidden"></form>';
                    }
                }
            ]
        });
    } );

    function deleteSiswa(index){
            Swal.fire({
            title: 'Restore siswa ini ?',
            html: 
            '<p>Berikut merupakan effect apabila admin merestore user</p>'+
            '<ul class="text-left">'+
            '<li>User akan dapat login ke dalam sistem kembali</li>'+
            '<li>Data user akan tetap, baik pendaftaran, kelas dan lain-lain</li>'+
            '<li>Kelas kemungkinan akan melebihi kapasitas apabila saat sebelum dipulihkan kelas user ini sudah full</li>'+
            '<li>Mohon pastikan semua administrasi user ini sudah lengkap untuk mencegah hal yang tidak diinginkan</li>'+
            '</ul>'
            ,
            icon:'warning',
            showDenyButton: true,
            showCancelButton: false,
            confirmButtonText: `Restore`,
            denyButtonText: `Batal`,
            }).then((result) => {
                
            if (result.isConfirmed) {
                $('#delete-siswa-'+index).submit();
            } else if (result.isDenied) {

            }
            })
        }
    
    // SWEETALERT2
        <?php if(Session::has('status')): ?>
            Swal.fire({
                icon:  <?php if(Session::has('icon')): ?><?php echo '"'.Session::get('icon').'"'; ?> <?php else: ?> 'question' <?php endif; ?>,
                title: <?php if(Session::has('title')): ?><?php echo '"'.Session::get('title').'"'; ?> <?php else: ?> 'Oppss...'<?php endif; ?>,
                text: <?php if(Session::has('message')): ?><?php echo '"'.Session::get('message').'"'; ?> <?php else: ?> 'Oppss...'<?php endif; ?>,
            });
        <?php endif; ?>
    // END
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('admin.admin-layout.admin-layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Pendaftaran_tci\core\resources\views/admin/admin/siswa/admin-trashed-siswa.blade.php ENDPATH**/ ?>