

<?php $__env->startPush('css'); ?>
<link rel="stylesheet" href="https://unpkg.com/swiper/swiper-bundle.min.css"/>
<link href="<?php echo e(asset('asset\css\user\user-pendaftaran.css')); ?>" rel="stylesheet">
<?php $__env->stopPush(); ?>

<?php $__env->startSection('navigation-wide'); ?>
    <?php echo $__env->make('user-dashboard.user-nav.top-nav-wide',['pendaftaran' => 'active'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('navigation-small'); ?>
    <?php echo $__env->make('user-dashboard.user-nav.top-nav-small', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <!-- CONTAINER -->
    <div class="container-fluid">
        <div class="row mt-3 animated slideInLeft position-relative" style="z-index:10;">
            <!-- DROPDOWN -->
            <div class="col-12">
                <div class="btn-group dropright">
                    
                    <button type="button" class="btn">
                        <?php if(isset($pendaftaran->nama_pendaftaran)): ?>
                            <?php echo e($pendaftaran->nama_pendaftaran); ?>

                        <?php else: ?>
                            Pilih Pendaftaran
                        <?php endif; ?>
                    </button>
                    
                    <button type="button" class="btn btn-secondary dropdown-toggle px-3" data-toggle="dropdown" aria-haspopup="true"
                        aria-expanded="false">
                        <span class="sr-only">Toggle Dropdown</span>
                    </button>

                    <div class="dropdown-menu">
                        <?php if(isset($semua_pendaftaran) && $semua_pendaftaran->count() > 0): ?>
                            <?php $__currentLoopData = $semua_pendaftaran; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pendaftaran_lain): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php
                                    $encrypt_id_pendaftaran = Crypt::encryptString($pendaftaran_lain->id);
                                ?>
                                <a class="dropdown-item" href="<?php echo e(Route('user.pendaftaran',[$encrypt_id_pendaftaran])); ?>"><?php echo e($pendaftaran_lain->nama_pendaftaran); ?></a>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
            <!-- END DROPDOWN -->

            <!-- PENGUMUMAN -->
            <div class="col-6">

            </div>
            <!-- END PENGUMUMAN -->
        </div>

        <div class="row mb-3 animated slideInRight">
            <!-- KELAS -->
            <div class="col-12 col-lg-8 overflow-hidden">
                <div class="swiper-container mySwiper w-100 h-100">
                    <div class="swiper-pagination"></div>
                    <div class="swiper-wrapper">
                        <?php if(isset($pendaftaran->Kelas)): ?>
                            <?php if($pendaftaran->Kelas->count() > 0): ?>
                                <?php $__currentLoopData = $pendaftaran->Kelas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $kelas): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="swiper-slide mb-5 mt-3">
                                        <!-- Card -->
                                        <div class="card"
                                            <?php if($kelas->isLocked): ?>
                                                style="opacity:.5;"
                                            <?php endif; ?>
                                        >

                                            <!-- Card image -->
                                            <?php if($kelas->logo_kelas != null): ?>
                                                <img class="card-img-top" src="<?php echo e(asset('storage\image_kelas').'\\'.$kelas->logo_kelas); ?>" alt="Card image cap" style="height:150px;object-fit:cover;">
                                            <?php else: ?>
                                                <img class="card-img-top" src="<?php echo e(asset('storage\image_kelas\default.jpg')); ?>" alt="Card image cap" style="height:150px;object-fit:cover;">
                                            <?php endif; ?>

                                            <!-- Card content -->
                                            <div class="card-body">

                                                <!-- Title -->
                                                <h4 class="card-title m-0" style="white-space: nowrap;overflow: hidden;text-overflow: ellipsis;">
                                                    <?php if(isset($kelas->nama_kelas)): ?>
                                                        <?php echo e($kelas->nama_kelas); ?>

                                                    <?php else: ?>
                                                        Unknown Class
                                                    <?php endif; ?>
                                                </h4>
                                                <p class="card-text p-0">
                                                    <?php if(isset($kelas->hsk)): ?>
                                                        <?php echo e(strtoupper($kelas->hsk)); ?>

                                                    <?php endif; ?>
                                                </p>

                                                <p class="card-text p-0 text-center">
                                                    <?php if($kelas->isLocked): ?>
                                                        <span class="rounded p-2 bg-danger z-depth-1 text-white">CLOSED</span>
                                                    <?php else: ?>
                                                    <?php if(isset($kelas->harga) && $kelas->isBerbayar): ?>
                                                        <span class="rounded p-2 bg-primary z-depth-1 text-white">IDR <?php echo e(number_format($kelas->harga)); ?></span>
                                                    <?php else: ?>
                                                        <span class="rounded p-2 bg-success z-depth-1 text-white">GRATIS</span>
                                                    <?php endif; ?>
                                                    <?php endif; ?>
                                                </p>
                                                
                                                <p class="card-text p-0 mb-0 mt-3">Kuota :</p>
                                                <h4><?php echo e($kelas->detail_kelas_count.'/'.$kelas->kuota); ?></h4>
                                                <?php
                                                    $persen = $kelas->detail_kelas_count/$kelas->kuota * 100;
                                                    $encrypt_kelas_id = Crypt::encryptString($kelas->id);
                                                ?>
                                                <div class="progress border border-secondary mb-3" style="height:30px;">
                                                <div class="progress-bar bg-secondary" role="progressbar" style="width: <?php echo e($persen); ?>%;" aria-valuenow="100" aria-valuemin="0" aria-valuemax="100"></div>
                                                </div>

                                                <div class="row m-0 p-0">
                                                    <div class="col-12 col-xl-6 m-xl-0 p-1">
                                                        <a href="<?php echo e(Route('user.jadwal.kelas',[$encrypt_kelas_id])); ?>" class="btn-sm btn-block btn-secondary">JADWAL</a>
                                                    </div>
                                                    <form action="<?php echo e(Route('user.daftar.kelas')); ?>" method="POST" id="form-daftar-kelas-<?php echo e($index); ?>">
                                                        <?php echo csrf_field(); ?>
                                                        <?php echo method_field('POST'); ?>
                                                        <input type="hidden" name="id_kelas" value="<?php echo e($encrypt_kelas_id); ?>">
                                                    </form>
                                                    <div class="col-12 col-xl-6 m-xl-0 p-1">
                                                        <a class="btn-sm btn-block btn-primary text-white" onclick="daftarKelas(<?php echo e($index); ?>,'<?php echo e($kelas->nama_kelas); ?>')">DAFTAR</a>
                                                    </div>
                                                </div>
                                                

                                            </div>
                                        
                                        </div>
                                        <!-- Card -->
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php else: ?>
                                <div class="d-flex flex-column justify-content-center align-items-center w-100">
                                    <div>
                                        <img src="<?php echo e(asset('asset\image\main_asset\nodata2.png')); ?>" alt="NO DATA" style="display:block;margin:auto;width:200px;">
                                    </div>

                                    <div>
                                        <h5 class="mt-5 text-center w-100">TIDAK ADA KELAS</h5>
                                    </div>
                                </div>
                            <?php endif; ?>
                        <?php else: ?>
                            <div class="d-flex flex-column justify-content-center align-items-center w-100">
                                <div>
                                    <img src="<?php echo e(asset('asset\image\main_asset\nodata2.png')); ?>" alt="NO DATA" style="display:block;margin:auto;width:200px;">
                                </div>

                                <div>
                                    <h5 class="mt-5 text-center w-100">TIDAK ADA KELAS</h5>
                                </div>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>

            </div>
            
            <!-- PENGUMUMAN -->
            <div class="col-12 col-lg-4">
                <div class="jumbotron overflow-hidden h-100 p-0">

                    <div class="text-center text-lg-left text-white font-weight-bold p-2" style="background: rgb(89,15,16);background: linear-gradient(90deg, rgba(89,15,16,1) 0%, rgba(207,29,32,1) 100%);">
                        PENGUMUMAN PENDAFTARAN
                    </div>
                    
                    <div class="swiper-container mySwiper2 h-100" id="pengumuman-responsive">
                        <div class="swiper-wrapper position-absolute" style="top:0px;left:0;right:0;bottom:10px;">
                            <?php if(isset($pendaftaran->PengumumanPendaftaran)): ?>
                                <?php if($pendaftaran->PengumumanPendaftaran->count() > 0): ?>
                                    <?php $__currentLoopData = $pendaftaran->PengumumanPendaftaran; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pengumuman): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="swiper-slide overflow-auto pb-5 pl-1 pr-1 pt-1">
                                        <?php echo $pengumuman->pengumuman; ?>

                                    </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php else: ?>
                                    <div class="d-flex flex-column justify-content-center align-items-center w-100">
                                        <div>
                                            <img src="<?php echo e(asset('asset\image\main_asset\nodata.png')); ?>" alt="NO DATA" style="display:block;margin:auto;width:100px;">
                                        </div>

                                        <div>
                                            <h5 class="mt-5 text-center w-100">TIDAK ADA PENGUMUMAN</h5>
                                        </div>
                                    </div>
                                <?php endif; ?>
                            <?php else: ?>
                                <div class="d-flex flex-column justify-content-center align-items-center w-100">
                                    <div>
                                        <img src="<?php echo e(asset('asset\image\main_asset\nodata.png')); ?>" alt="NO DATA" style="display:block;margin:auto;width:100px;">
                                    </div>

                                    <div>
                                        <h5 class="mt-5 text-center w-100">TIDAK ADA PENGUMUMAN</h5>
                                    </div>
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
                    
                </div>
            </div>
        </div>

    </div>
    <!-- END CONTAINER -->

<?php $__env->stopSection(); ?>

<?php $__env->startPush('js'); ?>
<script src="https://unpkg.com/swiper/swiper-bundle.min.js"></script>
<script>
        $(document).ready(function(){

            $('#navigation-button').click(function(){
                $('#navigation-block').toggleClass('active');
            })

            $('#navigation-button-close').click(function(){
                $('#navigation-block').toggleClass('active');
            })
        });
    
        var swiper = new Swiper(".mySwiper", {
            slidesPerView: 1,
            spaceBetween: 10,
            freeMode: false,
            pagination: {
            el: ".swiper-pagination",
            clickable: true,
            },
            breakpoints: {
            768: {
                slidesPerView: 2,
                spaceBetween: 10,
            },
            1024: {
                slidesPerView: 3,
                spaceBetween: 10,
            },
            },
        });

        var swiper2 = new Swiper(".mySwiper2", {
            slidesPerView: 1,
            autoplay: true,
            spaceBetween: 10,
            freeMode: false,
            disableOnInteraction: true,
            pagination: {
            el: ".swiper-pagination2",
            clickable: true,
            },
        });

        function daftarKelas(index,nama_kelas){

            Swal.fire({
            title: 'Yakin mengikuti kelas '+nama_kelas+' ?',
            icon:'question',
            showDenyButton: true,
            showCancelButton: false,
            confirmButtonText: `Ikuti`,
            denyButtonText: `Batal`,
            footer:'Saya telah menyetujui semua  &nbsp; <a href="#">   persyaratan dan persetujuan</a>',
            }).then((result) => {
                
            if (result.isConfirmed) {
                $('#form-daftar-kelas-'+index).submit();
            } else if (result.isDenied) {
            }
            })
            
        }

        // SWEETALERT2
            <?php if(Session::has('status')): ?>
                Swal.fire({
                    icon:  <?php if(Session::has('icon')): ?><?php echo '"'.Session::get('icon').'"'; ?> <?php else: ?> 'question' <?php endif; ?>,
                    title: <?php if(Session::has('title')): ?><?php echo '"'.Session::get('title').'"'; ?> <?php else: ?> 'Oppss...'<?php endif; ?>,
                    text: <?php if(Session::has('message')): ?><?php echo '"'.Session::get('message').'"'; ?> <?php else: ?> 'Oppss...'<?php endif; ?>,
                });
            <?php endif; ?>
        // END
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layout.main-layout.main-layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Pendaftaran_tci\core\resources\views/user-dashboard/user-pendaftaran.blade.php ENDPATH**/ ?>