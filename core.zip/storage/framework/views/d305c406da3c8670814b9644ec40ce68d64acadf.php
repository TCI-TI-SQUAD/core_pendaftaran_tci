

<?php $__env->startSection('siswa','active'); ?>

<?php $__env->startSection('page-name-header','Siswa'); ?>

<?php $__env->startSection('breadcrumb-item'); ?>
<li class="breadcrumb-item"><a href="<?php echo e(route('admin.dashboard')); ?>">Admin</a></li>
<li class="breadcrumb-item"> <a href="<?php echo e(route('admin.siswa')); ?>">Siswa</a></li>
<li class="breadcrumb-item active">Detail Siswa</li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-12 mb-4">
        <a href="<?php echo e(route('admin.edit.siswa').'/'.$user->id); ?>" class="btn btn-sm btn-info"><i class="far fa-edit"></i> EDIT SISWA</a>
        <a href="<?php echo e(route('admin.notifikasi.siswa.index',[$user->id])); ?>" class="btn btn-sm btn-warning"><i class="far fa-eye"></i> NOTIFIKASI PERINGATAN</a>  
        <button onclick="deleteSiswa(<?php echo e($user->id); ?>)" class="btn btn-sm btn-danger"><i class="far fa-trash-alt"></i> DELETE SISWA</button>
        <form action="<?php echo e(route('admin.delete.siswa')); ?>" method="POST" style="display:none;" id="delete-siswa-<?php echo e($user->id); ?>">
            <?php echo csrf_field(); ?>
            <?php echo method_field('delete'); ?>
            <input type="hidden" name="id" value="<?php echo e($user->id); ?>">
        </form>
        <a href="" class="btn btn-sm btn-secondary"><i class="fas fa-chalkboard-teacher"></i> LIHAT KELAS SISWA</a>
        <a href="<?php echo e(route('admin.email.siswa.index',[$user->id])); ?>" class="btn btn-sm btn-primary"><i class="fas fa-envelope-square"></i> KIRIM E-MAIL</a>
        <a target="__blank" class="btn btn-sm btn-info" href="https://wa.me/<?php echo e($user->phone_number); ?>?text=Halo, saya admin TCI, maksud saya menghubungi saudara adalah untuk "><i class="fab fa-whatsapp"></i> HUBUNGI VIA WA</a>
        <a target="__blank" class="btn btn-sm btn-success" href="http://line.me/ti/p/~<?php echo e($user->line); ?>"><i class="fab fa-whatsapp"></i> LIHAT LINE ID</a>
    </div>
    <div class="col-12 jumbotron shadow">
        <div class="container">
            <div class="row">
                <?php if(isset($user)): ?>
                    <div class="col-12 col-lg-3 text-center">
                        <?php if(isset($user->user_profile_pict)): ?>
                            <img src="<?php echo e(asset('storage/image_users').'/'.$user->user_profile_pict); ?>" alt="" style="width:200px;height:200px;object-fit:cover;" class="img-thumbnail rounded-circle">
                        <?php else: ?>
                            <img src="<?php echo e(asset('storage/image_users/default.jpg')); ?>" alt="" style="width:200px;height:200px;object-fit:cover;" class="img-thumbnail rounded-circle">
                        <?php endif; ?>
                    </div>
                    
                    <div class="col-12 col-lg-9">
                        <div class="container">
                            <div class="row">
                                <div class="col-12">
                                    <label >Name</label>
                                    <input type="text" class="form-control" value="<?php echo e($user->name); ?>" readonly>
                                    <label class="mt-2">Username</label>
                                    <input type="text" class="form-control" value="<?php echo e($user->username); ?>" readonly>
                                    <label class="mt-2">Nomor Pelajar TCi</label>
                                    <input type="text" class="form-control" value="<?php echo e($user->nomor_pelajar_tci); ?>" readonly>
                                    <label class="mt-2">Status Instansi Saat ini</label>
                                    <input type="text" class="form-control" value="<?php echo e($user->getInstansiName()); ?>" readonly>
                                    <label class="mt-2">Email</label>
                                    <input type="text" class="form-control" value="<?php echo e($user->email); ?>" readonly>
                                    <label class="mt-2">Phone Number</label>
                                    <input type="text" class="form-control" value="<?php echo e($user->phone_number); ?>" readonly>
                                    <label class="mt-2">Line</label>
                                    <input type="text" class="form-control" value="<?php echo e($user->line); ?>" readonly>
                                    <label class="mt-2">WA</label>
                                    <input type="text" class="form-control" value="<?php echo e($user->wa); ?>" readonly>
                                    <label class="mt-2">Alamat</label>
                                    <input type="text" class="form-control" value="<?php echo e($user->alamat); ?>" readonly>
                                    <label class="mt-2">Kartu Identitas [<?php echo e(strtoupper($user->jenis_kartu_identitas)); ?>]</label>
                                    <a target="__blank" href="<?php echo e(asset('storage/kartu_identitas').'/'.$user->kartu_identitas); ?>" class="btn btn-block btn-info">LIHAT KARTU IDENTITAS</a>
                                    <label class="mt-2">Hak Akses</label>
                                    <input type="text" class="form-control" value="<?php echo e(strtoupper($user->hak_akses)); ?>" readonly>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('js'); ?>
<script>
    $(document).ready( function () {

    });

    function deleteSiswa(index){
        Swal.fire({
        title: 'Hapus siswa ini ?',
        html: 
        '<p>Berikut merupakan effect apabila admin menghapus user</p>'+
        '<ul class="text-left">'+
        '<li>User tidak akan bisa login</li>'+
        '<li>User tidak akan terlihat di semua kelas yang telah diikuti</li>'+
        '<li>Jumlah anggota kelas akan berkurang</li>'+
        '<li>User masih dapat dipulihkan dengan halaman <span class="text-info">TRASHED</span></li>'+
        '<li>User akan hilang dari semua report</li>'+
        '<li>Saat dipulihkan user akan kembali seperti semula</li>'+
        '</ul>'
        ,
        icon:'warning',
        showDenyButton: true,
        showCancelButton: false,
        confirmButtonText: `Hapus`,
        denyButtonText: `Batal`,
        }).then((result) => {
            
        if (result.isConfirmed) {
            $('#delete-siswa-'+index).submit();
        } else if (result.isDenied) {

        }
        })
    }
        
    // SWEETALERT2
        <?php if(Session::has('status')): ?>
            Swal.fire({
                icon:  <?php if(Session::has('icon')): ?><?php echo '"'.Session::get('icon').'"'; ?> <?php else: ?> 'question' <?php endif; ?>,
                title: <?php if(Session::has('title')): ?><?php echo '"'.Session::get('title').'"'; ?> <?php else: ?> 'Oppss...'<?php endif; ?>,
                text: <?php if(Session::has('message')): ?><?php echo '"'.Session::get('message').'"'; ?> <?php else: ?> 'Oppss...'<?php endif; ?>,
            });
        <?php endif; ?>
    // END
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('admin.admin-layout.admin-layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Pendaftaran_tci\core\resources\views/admin/admin/siswa/admin-detail-siswa.blade.php ENDPATH**/ ?>