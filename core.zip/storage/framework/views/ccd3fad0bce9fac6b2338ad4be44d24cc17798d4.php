<a href="<?php echo e(Route('user.dashboard')); ?>" class="text-dark">
<div class="navigation-block-child mt-3">
        <div class="text-center" style="margin:10px;width:50px;"><i class="fas fa-home"></i></div>
        <div style="flex-grow:2;margin:10px;" class="<?php echo e(isset($home) ? 'font-weight-bold' : ''); ?>">Home</div>
    </div>
</a>

<a href="<?php echo e(Route('user.pendaftaran')); ?>" class="text-dark">
<div class="navigation-block-child mt-3">
        <div class="text-center" style="margin:10px;width:50px;"><i class="fas fa-question"></i></div>
        <div style="flex-grow:2;margin:10px;"  class="<?php echo e(isset($pendaftaran) ? 'font-weight-bold' : ''); ?>">Pendaftaran</div>
    </div>
</a>

<a href="<?php echo e(Route('user.kelas.saya')); ?>" class="text-dark">
<div class="navigation-block-child mt-3">
        <div class="text-center" style="margin:10px;width:50px;"><i class="far fa-address-book"></i></div>
        <div style="flex-grow:2;margin:10px;"  class="<?php echo e(isset($kelas_saya) ? 'font-weight-bold' : ''); ?>">Kelas Saya</div>
</div>
</a>

<a href="<?php echo e(Route('user.profile.index')); ?>" style="text-decoration:none;" class="text-dark">
    <div class="navigation-block-child mt-3">
            <div class="text-center" style="margin:10px;width:50px;"><i class="fas fa-sign-in-alt"></i></div>
            <div style="flex-grow:2;margin:10px;"  class="<?php echo e(isset($profile) ? 'font-weight-bold' : ''); ?>">Profile</div>
    </div>
</a>

<a href="<?php echo e(Route('user.notification.index')); ?>" style="text-decoration:none;" class="text-dark">
    <div class="navigation-block-child mt-3">
            <div class="text-center" style="margin:10px;width:50px;"><i class="fas fa-sign-in-alt"></i></div>
            <div style="flex-grow:2;margin:10px;"  class="<?php echo e(isset($notification) ? 'font-weight-bold' : ''); ?>">
                Notification <div class="badge badge-pill badge-danger"><?php if(isset($notifications)): ?> <?php echo e($notifications); ?> <?php endif; ?> </div>
            </div>
    </div>
</a>

<form action="<?php echo e(Route('user.post.logout')); ?>" method="post" id="form-logout" style="display:none;">
    <?php echo e(csrf_field()); ?>

    <?php echo e(method_field('POST')); ?>

</form>

<a style="text-decoration:none;" class="text-dark" onclick="document.getElementById('form-logout').submit()">
    <div class="navigation-block-child mt-3">
        <div class="text-center" style="margin:10px;width:50px;"><i class="far fa-registered"></i></div>
        <div style="flex-grow:2;margin:10px;">Log Out</div>
    </div>
</a><?php /**PATH C:\xampp\htdocs\Pendaftaran_tci\core\resources\views/user-dashboard/user-nav/top-nav-small.blade.php ENDPATH**/ ?>