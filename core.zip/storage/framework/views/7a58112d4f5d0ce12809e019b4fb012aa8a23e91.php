

<?php $__env->startSection('form'); ?>
<img src="<?php echo e(asset('asset\image\user-login\temple.png')); ?>" alt="">
            <div class="form-container animated fadeInUp">
                <form action="<?php echo e(Route('user.post.login')); ?>" method="POST" onsubmit="myButton.disabled = true; return true;">
                <?php echo e(csrf_field()); ?>

                <?php echo e(method_field('post')); ?>

                <h4 class="font-weight-bold text-center mt-5">
                    <?php if(isset($jam)): ?>
                        <?php if($jam >= 0 && $jam < 10): ?>
                            Selamat Pagi !
                        <?php elseif($jam >= 10 && $jam < 15): ?>
                            Selamat Siang !
                        <?php elseif($jam >= 15 && $jam < 18): ?>
                            Selamat Sore !
                        <?php elseif($jam >= 18 && $jam < 24): ?>
                            Selamat Malam !
                        <?php else: ?>
                            Selamat Datang
                        <?php endif; ?>
                    <?php endif; ?>
                </h4>

                <label for="exampleForm2" class="mt-5">Email</label>
                <input name="email" type="text" id="exampleForm2" class="form-control mt-1 <?php if($errors->has('email')): ?><?php echo e('border border-danger'); ?><?php endif; ?>" minlength="5" maxlength="50">
                <?php if($errors->has('email')): ?><small class="text-danger"><?php echo e($errors->first('email')); ?></small><?php endif; ?>

                <label class="mt-3" for="exampleForm2">Password</label>
                <input name="password" type="password" id="exampleForm2" class="form-control mt-1 <?php if($errors->has('email')): ?><?php echo e('border border-danger'); ?><?php endif; ?>" minlength="5" maxlength="100">
                <?php if($errors->has('password')): ?><small class="text-danger"><?php echo e($errors->first('password')); ?></small><?php endif; ?>

                <div class="my-4">
                    <?php echo NoCaptcha::display(); ?>

                    <?php echo NoCaptcha::renderJs(); ?>

                    <?php $__errorArgs = ['g-recaptcha-response'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="text-danger"><small>Mohon Input Captcha !</small></p><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div class="row mt-3">
                    <div class="col m-2">
                        <div class="custom-control custom-checkbox">
                            <input type="checkbox" class="custom-control-input" id="defaultUnchecked" value="1" name="remember_me">
                            <label class="custom-control-label" for="defaultUnchecked">Remember me</label>
                        </div>
                    </div>
                    <div class="col m-2">
                        <a href="">
                            <p class="w-100 text-right"><u>Lupa Password ?</u></p>
                        </a>
                    </div>
                </div>

                <button name="myButton" class="btn btn-block btn-success mt-5" type="submit">LOGIN</button>
                <a class="btn btn-block btn-danger mt-1" href="<?php echo e(route('user.landing-page')); ?>">BACK</a>

                <p class="text-center mt-4">Dont have an account ? <a href="<?php echo e(route('user.register')); ?>">Register Here</a></p>
                <p class="text-center mt-1">Visit us on</p>

                <div class="d-flex justify-content-center mb-4">
                    <?php if(isset($social_medias)): ?>
                        <?php $__currentLoopData = $social_medias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $social_media): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <a  data-toggle="tooltip" title="<?php echo e($social_media->keterangan); ?>" href="<?php echo e($social_media->link); ?>" class="m-1"><img style="height:30px;width:30px;position:relative;" src="<?php echo e(url('asset\image\social-media',[$social_media->social_media_image])); ?>" alt="social_media_image"></a>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                </div>

                </form>
            </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('bottom_source'); ?>
<script>
    // SWEETALERT2
    
    <?php if(Session::has('status')): ?>
        Swal.fire({
            icon:  <?php if(Session::has('icon')): ?><?php echo '"'.Session::get('icon').'"'; ?> <?php else: ?> 'question' <?php endif; ?>,
            title: <?php if(Session::has('title')): ?><?php echo '"'.Session::get('title').'"'; ?> <?php else: ?> 'Oppss...'<?php endif; ?>,
            text: <?php if(Session::has('message')): ?><?php echo '"'.Session::get('message').'"'; ?> <?php else: ?> 'Oppss...'<?php endif; ?>,
        });
    <?php endif; ?>
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layout.auth.user-login-template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Pendaftaran_tci\core\resources\views/user-auth/user-login.blade.php ENDPATH**/ ?>