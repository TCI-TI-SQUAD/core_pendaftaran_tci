

<?php $__env->startSection('dashboard','active'); ?>

<?php $__env->startSection('page-name-header','Dashboard'); ?>

<?php $__env->startSection('breadcrumb-item'); ?>
<li class="breadcrumb-item"><a href="#">Admin</a></li>
<li class="breadcrumb-item active">Dashboard</li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('admin.dashboard.user-active-component', [])->html();
} elseif ($_instance->childHasBeenRendered('cHFleyQ')) {
    $componentId = $_instance->getRenderedChildComponentId('cHFleyQ');
    $componentTag = $_instance->getRenderedChildComponentTagName('cHFleyQ');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('cHFleyQ');
} else {
    $response = \Livewire\Livewire::mount('admin.dashboard.user-active-component', []);
    $html = $response->html();
    $_instance->logRenderedChild('cHFleyQ', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('admin.dashboard.pendaftaran-component', [])->html();
} elseif ($_instance->childHasBeenRendered('1kJeNvk')) {
    $componentId = $_instance->getRenderedChildComponentId('1kJeNvk');
    $componentTag = $_instance->getRenderedChildComponentTagName('1kJeNvk');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('1kJeNvk');
} else {
    $response = \Livewire\Livewire::mount('admin.dashboard.pendaftaran-component', []);
    $html = $response->html();
    $_instance->logRenderedChild('1kJeNvk', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('admin.dashboard.kelas-active-component', [])->html();
} elseif ($_instance->childHasBeenRendered('E6GNsNK')) {
    $componentId = $_instance->getRenderedChildComponentId('E6GNsNK');
    $componentTag = $_instance->getRenderedChildComponentTagName('E6GNsNK');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('E6GNsNK');
} else {
    $response = \Livewire\Livewire::mount('admin.dashboard.kelas-active-component', []);
    $html = $response->html();
    $_instance->logRenderedChild('E6GNsNK', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('admin.dashboard.transaksi-menunggu-konfirmasi-component', [])->html();
} elseif ($_instance->childHasBeenRendered('1cToLog')) {
    $componentId = $_instance->getRenderedChildComponentId('1cToLog');
    $componentTag = $_instance->getRenderedChildComponentTagName('1cToLog');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('1cToLog');
} else {
    $response = \Livewire\Livewire::mount('admin.dashboard.transaksi-menunggu-konfirmasi-component', []);
    $html = $response->html();
    $_instance->logRenderedChild('1cToLog', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('admin.dashboard.chart-instansi-user-component', [])->html();
} elseif ($_instance->childHasBeenRendered('l4oIHP9')) {
    $componentId = $_instance->getRenderedChildComponentId('l4oIHP9');
    $componentTag = $_instance->getRenderedChildComponentTagName('l4oIHP9');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('l4oIHP9');
} else {
    $response = \Livewire\Livewire::mount('admin.dashboard.chart-instansi-user-component', []);
    $html = $response->html();
    $_instance->logRenderedChild('l4oIHP9', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('admin.dashboard.countdown-pengumuman-component', [])->html();
} elseif ($_instance->childHasBeenRendered('VMLhhnJ')) {
    $componentId = $_instance->getRenderedChildComponentId('VMLhhnJ');
    $componentTag = $_instance->getRenderedChildComponentTagName('VMLhhnJ');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('VMLhhnJ');
} else {
    $response = \Livewire\Livewire::mount('admin.dashboard.countdown-pengumuman-component', []);
    $html = $response->html();
    $_instance->logRenderedChild('VMLhhnJ', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('admin.dashboard.register-hari-ini-component', [])->html();
} elseif ($_instance->childHasBeenRendered('3LAoI9s')) {
    $componentId = $_instance->getRenderedChildComponentId('3LAoI9s');
    $componentTag = $_instance->getRenderedChildComponentTagName('3LAoI9s');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('3LAoI9s');
} else {
    $response = \Livewire\Livewire::mount('admin.dashboard.register-hari-ini-component', []);
    $html = $response->html();
    $_instance->logRenderedChild('3LAoI9s', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.admin-layout.admin-layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Pendaftaran_tci\core\resources\views/admin/admin/admin-dashboard.blade.php ENDPATH**/ ?>