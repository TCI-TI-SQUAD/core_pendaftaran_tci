

<?php $__env->startPush('css'); ?>
<link rel="stylesheet" href="<?php echo e(asset('plugins\swiper\swiper-bundle.min.css')); ?>">
<link href="<?php echo e(asset('asset\vendor\flipdown-master\dist\flipdown.min.css')); ?>" rel="stylesheet">
<link href="<?php echo e(asset('asset\css\layout-css\user-dashboard-layout.css')); ?>" rel="stylesheet">
<?php $__env->stopPush(); ?>

<?php $__env->startSection('navigation-wide'); ?>
    <?php echo $__env->make('user-dashboard.user-nav.top-nav-wide',['notification' => 'active'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('navigation-small'); ?>
    <?php echo $__env->make('user-dashboard.user-nav.top-nav-small',['notification' => 'active'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <!-- CONTAINER -->
    <div class="container h-100 p-3">
        <div class="row">
            <div class="col-12">
                <h5 class="font-weight-bold text-center text-lg-left">USER NOTIFICATIONS</h5>
            </div>
            <div class="col-12 text-center text-lg-left">
                <a href="<?php echo e(route('user.notification.index',['unread'])); ?>" class="btn btn-info btn-sm <?php if(isset($filter)): ?> <?php if($filter == 'unread'): ?> active <?php endif; ?> <?php endif; ?>">UNREAD</a>
                <a href="<?php echo e(route('user.notification.index',['read'])); ?>" class="btn btn-info btn-sm  <?php if(isset($filter)): ?> <?php if($filter == 'read'): ?> active <?php endif; ?> <?php endif; ?>">READ</a>
                <a href="" class="btn btn-secondary btn-sm">MARK AS READ ALL</a>
            </div>
        </div>
        <div class="row mt-3">
            <div class="col-12 p-2 animated slideInUp" style="min-height:500px;">
            <?php if(isset($user_notifications)): ?>
                <?php if($user_notifications->count() > 0): ?>
                    <?php $__currentLoopData = $user_notifications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $user_notification): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php $full_data = $user_notification->getFullDataAttribute() ?>
                        <div class="<?php if(isset($full_data->color)): ?> <?php echo $full_data->color; ?> <?php endif; ?> rounded z-depth-1 my-3">
                            <div class="toast-header">
                                <p class="h1 m-2"><?php if(isset($full_data->icon)): ?><i class="fa <?php echo $full_data->icon; ?>"></i> <?php endif; ?></p>
                                <strong class="mr-auto ml-3 font-weight-bold"><?php if(isset($full_data->title)): ?> <?php echo e(strtoupper($full_data->title)); ?> <?php endif; ?></strong>
                                <small><?php if(isset($full_data->datetime)): ?> <?php echo e($full_data->datetime); ?> <?php endif; ?></small>
                                </button>
                            </div>
                            <div class="toast-body bg-white py-4">
                                <?php if(isset($full_data->message)): ?> <?php echo $full_data->message; ?> <?php endif; ?>
                            </div>
                            <div class="text-right">
                                <button class="btn btn-md btn-white m-2">MARK AS READ</button>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php else: ?>
                    <div class="h-100 d-flex flex-column align-items-center justify-content-center text-center">
                        <img src="<?php echo e(asset('asset\image\main_asset\nodata2.png')); ?>" alt="" style="width:200px;">
                        <h5 class="mt-5">TIDAK ADA NOTIFIKASI</h5>
                    </div>
                <?php endif; ?>
            <?php else: ?>
                <div class="h-100 d-flex flex-column align-items-center justify-content-center text-center">
                    <img src="<?php echo e(asset('asset\image\main_asset\nodata2.png')); ?>" alt="" style="width:200px;">
                    <h5 class="mt-5">TIDAK ADA NOTIFIKASI</h5>
                </div>
            <?php endif; ?>
            </div>
        </div>
    </div>
    <!-- END CONTAINER -->
<?php $__env->stopSection(); ?>

<?php $__env->startPush('js'); ?>
<script>
    $(document).ready(function(){

        $('#navigation-button').click(function(){
            $('#navigation-block').toggleClass('active');
        })

        $('#navigation-button-close').click(function(){
            $('#navigation-block').toggleClass('active');
        })

    });
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layout.main-layout.main-layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Pendaftaran_tci\core\resources\views/user-dashboard\user-notification\user-notification.blade.php ENDPATH**/ ?>