<div class="col-12 pt-5">
    <div class="container jumbotron shadow p-0 w-100">
        <div class="row">
            <div class="col-12">
                <h5 class="p-2 bg-primary font-weight-bold text-center text-lg-left">REGISTRASI BARU HARI INI</h5>
            </div>
            <div class="col-12 p-3">
                
                    <table class="table responsive nowrap" width="100%" id="table_id">
                    <thead>
                        <tr>
                        <th scope="col">#</th>
                        <th scope="col">Nama</th>
                        <th scope="col">HSK</th>
                        <th scope="col">Nomor Pelajar TCI</th>
                        <th scope="col">Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if(isset($users)): ?>
                            <?php if(count($users) > 0): ?>
                                <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                    <th scope="row"><?php echo e($index+1); ?></th>
                                    <td><?php echo e($user['name']); ?></td>
                                    <td><?php echo e(strtoupper($user['hsk'])); ?></td>
                                    <td><?php echo e($user['nomor_pelajar_tci']); ?></td>
                                    <td><button class="btn-primary rounded"><i class="far fa-eye"></i></button><button class="btn-info rounded"><i class="fas fa-edit"></i></button></td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                        <?php endif; ?>
                    </tbody>
                    </table>

                
            </div>
        </div>
    </div>
</div>

<?php $__env->startPush('css'); ?>
    <!-- DataTables -->
    <link rel="stylesheet" href="<?php echo e(asset('plugins\datatables-bs4\css\dataTables.bootstrap4.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('plugins\datatables-responsive\css\responsive.bootstrap4.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('plugins\datatables-buttons\css\buttons.bootstrap4.min.css')); ?>">
<?php $__env->stopPush(); ?>

<?php $__env->startPush('js'); ?>
<script src="<?php echo e(asset('plugins/datatables/jquery.dataTables.min.js')); ?>"></script>
<script src="<?php echo e(asset('plugins/datatables-bs4/js/dataTables.bootstrap4.min.js')); ?>"></script>
<script src="<?php echo e(asset('plugins/datatables-responsive/js/dataTables.responsive.min.js')); ?>"></script>
<script src="<?php echo e(asset('plugins/datatables-responsive/js/responsive.bootstrap4.min.js')); ?>"></script>
<script src="<?php echo e(asset('plugins/datatables-buttons/js/dataTables.buttons.min.js')); ?>"></script>
<script src="<?php echo e(asset('plugins/datatables-buttons/js/buttons.bootstrap4.min.js')); ?>"></script>
<script src="<?php echo e(asset('plugins/jszip/jszip.min.js')); ?>"></script>
<script src="<?php echo e(asset('plugins/pdfmake/pdfmake.min.js')); ?>"></script>
<script src="<?php echo e(asset('plugins/pdfmake/vfs_fonts.js')); ?>"></script>
<script src="<?php echo e(asset('plugins/datatables-buttons/js/buttons.html5.min.js')); ?>"></script>
<script src="<?php echo e(asset('plugins/datatables-buttons/js/buttons.print.min.js')); ?>"></script>
<script src="<?php echo e(asset('plugins/datatables-buttons/js/buttons.colVis.min.js')); ?>"></script>

<script>
    $(document).ready( function () {
        $('#table_id').DataTable({
            responsive: true
        });
    } );
</script>
<?php $__env->stopPush(); ?><?php /**PATH C:\xampp\htdocs\Pendaftaran_tci\core\resources\views/livewire/admin/dashboard/register-hari-ini-component.blade.php ENDPATH**/ ?>