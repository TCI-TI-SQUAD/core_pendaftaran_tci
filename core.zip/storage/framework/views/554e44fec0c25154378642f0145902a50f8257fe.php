<li>        
    <a class="text-dark <?php echo e(isset($home) ? 'font-weight-bold' : ''); ?>" href="<?php echo e(Route('user.dashboard')); ?>">Home</a>
</li>
<li>
    <a class="text-dark <?php echo e(isset($pendaftaran) ? 'font-weight-bold' : ''); ?>" href="<?php echo e(Route('user.pendaftaran')); ?>">Pendaftaran</a>
</li>
<li  class="pr-2">
    <a class="text-dark <?php echo e(isset($kelas_saya) ? 'font-weight-bold' : ''); ?>" href="<?php echo e(Route('user.kelas.saya')); ?>">Kelas Saya</a>
</li>
<li>
    <a class="text-dark <?php echo e(isset($profile) ? 'font-weight-bold' : ''); ?>" href="<?php echo e(Route('user.profile.index')); ?>">Profile</a>
</li>

<form action="<?php echo e(Route('user.post.logout')); ?>" method="post" id="form-logout-wide" style="display:none;">
    <?php echo e(csrf_field()); ?>

    <?php echo e(method_field('POST')); ?>

</form>

<li>
    <button type="submit" form="form-logout-wide" class="btn btn-outline-danger waves-effect">Log Out</button>
</li><?php /**PATH C:\xampp\htdocs\Pendaftaran_tci\core\resources\views/user-dashboard/user-nav/top-nav-wide.blade.php ENDPATH**/ ?>