
<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">

    <title>Admin TCI UDAYANA</title>

    <!-- Bootstrap core CSS -->
    <link href="<?php echo e(asset('asset\vendor\mdbootstrap\css\bootstrap.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('asset\vendor\mdbootstrap\css\main.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css\app.css')); ?>" rel="stylesheet">

  </head>

  <body style="width:100vw;height:100vh;">
    <div class="container h-100">
        <div class="row justify-content-center align-items-center h-100">
            <div class="col-12 col-lg-4 text-center">
                <form class="form-signin" method="POST" action="<?php echo e(Route('admin.auth.login.post')); ?>" onsubmit="myButton.disabled = true; return true;">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('POST'); ?>
                    <img class="mb-4" src="<?php echo e(asset('asset\image\main_asset\logo.png')); ?>" alt="" style="width:200px;">
                    <h1 class="h4 mb-3 font-weight-bold my-4">WELCOME WAH KOMO TCI</h1>
                    <label for="inputEmail" class="sr-only">Email address</label>
                    <input name="email" type="email" id="inputEmail" class="form-control my-2" placeholder="Email address" required autofocus>

                    <label for="inputPassword" class="sr-only">Password</label>
                    <input name="password" type="password" id="inputPassword" class="form-control my-2" placeholder="Password" required>

                    <div class="checkbox mb-3">
                        <label>
                        <input type="checkbox" value="1" name="rememberme"> Remember me
                        </label>
                    </div>
                    <div class="my-3">
                        <?php echo NoCaptcha::display(); ?>

                        <?php echo NoCaptcha::renderJs(); ?>

                        <?php $__errorArgs = ['g-recaptcha-response'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="text-danger"><small>Mohon Input Captcha !</small></p><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <button name="myButton" class="btn btn-lg btn-primary btn-block" type="submit">Sign in</button>
                    <p class="mt-5 mb-3 text-muted">&copy; RICHARD & ALSAN TECH 2021</p>
                </form>
            </div>
        </div>
    </div>

    <script type="text/javascript" src="<?php echo e(asset('asset\vendor\mdbootstrap\js\jquery.min.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(asset('asset\vendor\mdbootstrap\js\popper.min.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(asset('asset\vendor\mdbootstrap\js\bootstrap.min.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(asset('asset\vendor\mdbootstrap\js\mdb.min.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(asset('js\app.js')); ?>"></script>
    <script>

        // SWEETALERT2
            <?php if(Session::has('status')): ?>
                Swal.fire({
                    icon:  <?php if(Session::has('icon')): ?><?php echo '"'.Session::get('icon').'"'; ?> <?php else: ?> 'question' <?php endif; ?>,
                    title: <?php if(Session::has('title')): ?><?php echo '"'.Session::get('title').'"'; ?> <?php else: ?> 'Oppss...'<?php endif; ?>,
                    text: <?php if(Session::has('message')): ?><?php echo '"'.Session::get('message').'"'; ?> <?php else: ?> 'Oppss...'<?php endif; ?>,
                });
            <?php endif; ?>
        // END
    </script>
  </body>
</html>
<?php /**PATH C:\xampp\htdocs\Pendaftaran_tci\core\resources\views/admin/admin-auth/admin-login.blade.php ENDPATH**/ ?>