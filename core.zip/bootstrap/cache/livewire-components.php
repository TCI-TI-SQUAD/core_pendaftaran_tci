<?php return array (
  'admin.dashboard.chart-instansi-user-component' => 'App\\Http\\Livewire\\Admin\\Dashboard\\ChartInstansiUserComponent',
  'admin.dashboard.countdown-pengumuman-component' => 'App\\Http\\Livewire\\Admin\\Dashboard\\CountdownPengumumanComponent',
  'admin.dashboard.kelas-active-component' => 'App\\Http\\Livewire\\Admin\\Dashboard\\KelasActiveComponent',
  'admin.dashboard.pendaftaran-component' => 'App\\Http\\Livewire\\Admin\\Dashboard\\PendaftaranComponent',
  'admin.dashboard.register-hari-ini-component' => 'App\\Http\\Livewire\\Admin\\Dashboard\\RegisterHariIniComponent',
  'admin.dashboard.transaksi-menunggu-konfirmasi-component' => 'App\\Http\\Livewire\\Admin\\Dashboard\\TransaksiMenungguKonfirmasiComponent',
  'admin.dashboard.user-active-component' => 'App\\Http\\Livewire\\Admin\\Dashboard\\UserActiveComponent',
);